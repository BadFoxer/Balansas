<table>
    <thead>
  <tr>
    <th>Mėnesiai</th>
    <th>Pajamos</th>
    <th>Išlaidos</th>
    <th>Balansas</th>
  </tr>
</thead>
<tbody id="myTableData">
</tbody>
</table>
